//
//  ProjetoApp.swift
//  Projeto
//
//  Created by Turma01-28 on 09/04/25.
//

import SwiftUI

@main
struct ProjetoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
