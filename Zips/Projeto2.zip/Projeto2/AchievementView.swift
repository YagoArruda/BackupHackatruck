//
//  AchievementView.swift
//  Projeto
//
//  Created by Turma01-25 on 07/04/25.
//

import SwiftUI

struct AchievementView: View {
    
    @State private var conquistas: [Conquista] = [
        .init(icon: "list.bullet.clipboard.fill", iconColor: .white, mensagem: "Primeiro Dia"),
        .init(icon: "trophy.fill", iconColor: .yellow, mensagem: "1º Tarefa", valor: 1),
        .init(icon: "trophy.fill", iconColor: .yellow, mensagem: "10º Tarefa", valor: 10),
        .init(icon: "trophy.fill", iconColor: .yellow, mensagem: "100º Tarefa", valor: 100),
        .init(icon: "trophy.fill", iconColor: .yellow, mensagem: "1000º Tarefa", valor: 1000)
    ]
    
    var body: some View {
        
        //Valor para teste - substituir depois pelo dado do usuario
        @State var tarefasUsuario = 0
            ZStack {
                Color.gray.opacity(0.2)
                    .ignoresSafeArea()
                VStack {
                    Title(message: "Conquistas")
                ScrollView {
                    
                    ForEach(conquistas) { conquista in
                        Achievement(icon: conquista.icon, iconColor: conquista.iconColor, text: conquista.mensagem,tarefasFeitas: tarefasUsuario,valor: conquista.valor ?? 0)
                    }
                    
                }
            }
        }
        
        
    }
}

#Preview {
    AchievementView()
}
