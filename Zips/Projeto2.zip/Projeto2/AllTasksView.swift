//
//  AllTasksView.swift
//  Projeto
//
//  Created by Turma01-28 on 09/04/25.
//

import SwiftUI

struct AllTasksView: View {
    @State private var tarefas_Exemplo: [Tarefa1] = [
        .init(nome: "At1", tipo: "Fazer"),
        .init(nome: "At2", tipo: "Fazer"),
        .init(nome: "At3", tipo: "Fazer"),
        .init(nome: "At4", tipo: "Fazendo"),
        .init(nome: "At5", tipo: "Fazendo"),
        .init(nome: "At6", tipo: "Fazendo"),
        .init(nome: "At7", tipo: "Feito"),
        .init(nome: "At8", tipo: "Feito"),
        .init(nome: "At9", tipo: "Feito")
    ]
    
    
    var body: some View {
        VStack{
            
            ZStack {
                Color.gray.opacity(0.2)
                    .ignoresSafeArea()
                VStack{
                    Title(message: "Tarefas")
                    StatusChart(tarefas: tarefas_Exemplo, width: 200, height: 200)
                    ChartSubtitlesH()
                    /* ChartSubtitlesNumbers(finalizadas: tarefas_Exemplo.filter { $0.tipo == "Feito" }.count, fazendo: tarefas_Exemplo.filter { $0.tipo == "Feito" }.count, afazer: tarefas_Exemplo.filter { $0.tipo == "Feito" }.count) */
                    Spacer()
                    Card(icon: "flame.fill", text: "\(0) Dias Seguidos")
                    Spacer()
                }
            }
        }
    }
}
#Preview {
    AllTasksView()
}
