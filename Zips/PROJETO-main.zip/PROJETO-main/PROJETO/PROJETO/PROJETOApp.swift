//
//  PROJETOApp.swift
//  PROJETO
//
//  Created by Turma01-19 on 03/04/25.
//

import SwiftUI

@main
struct PROJETOApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
